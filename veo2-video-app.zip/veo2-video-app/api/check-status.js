import fetch from "node-fetch";

export default async function handler(req, res) {
  const { name } = req.query;

  if (!name) {
    return res.status(400).json({ error: "Job name diperlukan" });
  }

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/${name}?key=${process.env.GOOGLE_API_KEY}`
    );
    const data = await response.json();
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: error.toString() });
  }
}